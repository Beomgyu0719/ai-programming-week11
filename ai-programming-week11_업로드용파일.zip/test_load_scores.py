import pytest
from load_scores import load_scores


def write_csv(filename, content):
    with open(filename, "w", encoding="utf-8", newline="") as f:
        f.write(content)


def test_정상_파일을_읽는다(tmp_path):
    p = tmp_path / "normal.csv"
    write_csv(p, "이름,점수\n김하나,88\n이둘,92\n박셋,75\n")
    kept, skipped = load_scores(p)
    assert kept == [("김하나", 88), ("이둘", 92), ("박셋", 75)]
    assert skipped == []


def test_빈_줄은_건너뛴다(tmp_path):
    p = tmp_path / "blank_lines.csv"
    write_csv(p, "이름,점수\n김하나,88\n\n이둘,92\n\n")
    kept, skipped = load_scores(p)
    assert kept == [("김하나", 88), ("이둘", 92)]
    assert skipped == []


def test_이름에_쉼표가_있어도_읽는다(tmp_path):
    p = tmp_path / "comma_name.csv"
    write_csv(p, '이름,점수\n"김,하나",88\n')
    kept, skipped = load_scores(p)
    assert kept == [("김,하나", 88)]
    assert skipped == []


def test_동명이인은_둘_다_남긴다(tmp_path):
    p = tmp_path / "duplicate.csv"
    write_csv(p, "이름,점수\n김하나,88\n김하나,95\n")
    kept, skipped = load_scores(p)
    assert kept == [("김하나", 88), ("김하나", 95)]
    assert skipped == []


def test_없는_파일이면_오류가_난다():
    with pytest.raises(FileNotFoundError):
        load_scores("존재하지_않는_파일.csv")


def test_헤더만_있으면_빈_결과가_나온다(tmp_path):
    p = tmp_path / "empty.csv"
    write_csv(p, "이름,점수\n")
    kept, skipped = load_scores(p)
    assert kept == []
    assert skipped == []


@pytest.mark.parametrize(
    "점수, 유효한가",
    [
        (-1, False),
        (0, True),
        (1, True),
        (99, True),
        (100, True),
        (101, False),
    ],
)
def test_점수_경계값(tmp_path, 점수, 유효한가):
    p = tmp_path / "boundary.csv"
    write_csv(p, f"이름,점수\n홍길동,{점수}\n")
    kept, skipped = load_scores(p)
    assert (len(kept) == 1) == 유효한가


def test_잘못된_형식의_줄은_건너뛰고_기록한다(tmp_path):
    p = tmp_path / "invalid.csv"
    content = (
        "이름,점수\n"
        "김하나\n"
        "이둘,80,90\n"
        ",85\n"
        "박셋,\n"
        "최넷,팔십점\n"
    )
    write_csv(p, content)
    kept, skipped = load_scores(p)
    assert kept == []
    assert len(skipped) == 5
    assert skipped[0][2] == "열 개수가 2가 아님"
    assert skipped[1][2] == "열 개수가 2가 아님"
    assert skipped[2][2] == "이름이 비어 있음"
    assert skipped[3][2] == "점수가 비어 있음"
    assert skipped[4][2] == "점수가 정수가 아님"
