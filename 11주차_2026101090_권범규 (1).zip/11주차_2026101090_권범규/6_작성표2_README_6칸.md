# [워크시트 6] 작성표 ② — README 여섯 칸 요약
* **학번 / 이름**: 2026101090 / 권범규

| 칸 | 내용 |
| :--- | :--- |
| **① What (무엇을 하나요)** | 성적 CSV 파일을 읽어 유효한 학생 이름과 점수(0~100점 정수) 목록(`kept`)을 추출하고, 잘못된 행은 건너뛴 기록(`skipped`)으로 분리해 반환하는 프로그램입니다. |
| **② Why (왜 만들었나요)** | 실제 성적 CSV에는 빈 줄, 누락 값, 범위 초과 점수, 동명이인이 섞여 있어 단순 파싱 시 오류가 발생하므로, 명세 기반 데이터 검증과 `pytest` 단위 테스트로 신뢰성을 보장하기 위해 만들었습니다. |
| **③ How (어떻게 쓰나요)** | `pip install pytest pytest-cov` 설치 후 `python3 load_scores.py scores.csv` 명령어로 실행합니다. |
| **④ 테스트 (어떻게 테스트하나요)** | `pytest test_load_scores.py` 및 `pytest --cov=load_scores --cov-report=term-missing` 명령어로 전체 테스트 통과 여부와 커버리지를 확인합니다. |
| **⑤ 파일 구성** | `load_scores.py`(핵심 모듈), `test_load_scores.py`(직접 작성 테스트), `test_ai_A.py`(코드 기반 AI 테스트), `test_ai_B.py`(명세 기반 AI 테스트), `scores.csv`/`empty.csv`/`weird.csv`(샘플 데이터), `LICENSE` |
| **⑥ 만든 사람** | 권범규 (2026101090) / AI 활용 내역: 프롬프트 A·B 비교 실험 및 경계값 테스트·문서 초안 검토에 활용 |
